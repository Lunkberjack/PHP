<?php
    if(isset($_COOKIE['Contador'])) {
        printf("La id tras cerrar es: ".$_COOKIE['Contador']);
    }
?>